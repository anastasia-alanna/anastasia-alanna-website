CORRECTED FOOTER LOGO FIX

Replace:
assets/js/main.js

This version changes only the footer logo to:
assets/images/logo-stacked.png

The header logo remains unchanged.
